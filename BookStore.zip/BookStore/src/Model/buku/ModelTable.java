package Model.Buku;

import javax.swing.table.AbstractTableModel;
import java.util.List;

public class ModelTable extends AbstractTableModel {
    private List<ModelBuku> data;
    private String[] columns = {"ID", "Nama Penyewa", "Judul Buku", "Jenis Buku", "Nomor Telepon", "Durasi Sewa", "Total Biaya"};

    public ModelTable(List<ModelBuku> data) {
        this.data = data;
    }

    @Override
    public int getRowCount() {
        return data.size();
    }

    @Override
    public int getColumnCount() {
        return columns.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        ModelBuku buku = data.get(rowIndex);
        switch (columnIndex) {
            case 0:
                return buku.getId();
            case 1:
                return buku.getNamaPenyewa();
            case 2:
                return buku.getJudulBuku();
            case 3:
                return buku.getJenisBuku();
            case 4:
                return buku.getNomorTelepon();
            case 5:
                return buku.getDurasiSewa();
            case 6:
                return buku.getTotalBiaya();
            default:
                return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        return columns[column];
    }
}
