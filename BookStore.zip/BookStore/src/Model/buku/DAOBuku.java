package Model.Buku;

import Model.Connector;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DAOBuku implements InterfaceDAOBuku {

    @Override
    public void insert(ModelBuku buku) {
        try {
            String query = "INSERT INTO sewa_buku (nama_penyewa, judul_buku, jenis_buku, nomor_telepon, durasi_sewa, total_biaya) VALUES (?, ?, ?, ?, ?, ?)";
            int totalBiaya = hitungTotalBiaya(buku.getDurasiSewa());
            PreparedStatement statement = Connector.connect().prepareStatement(query);
            statement.setString(1, buku.getNamaPenyewa());
            statement.setString(2, buku.getJudulBuku());
            statement.setString(3, buku.getJenisBuku());
            statement.setString(4, buku.getNomorTelepon());
            statement.setInt(5, buku.getDurasiSewa());
            statement.setInt(6, totalBiaya);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Input Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public void update(ModelBuku buku) {
        try {
            String query = "UPDATE sewa_buku SET nama_penyewa=?, judul_buku=?, jenis_buku=?, nomor_telepon=?, durasi_sewa=?, total_biaya=? WHERE id=?";
            int totalBiaya = hitungTotalBiaya(buku.getDurasiSewa());
            PreparedStatement statement = Connector.connect().prepareStatement(query);
            statement.setString(1, buku.getNamaPenyewa());
            statement.setString(2, buku.getJudulBuku());
            statement.setString(3, buku.getJenisBuku());
            statement.setString(4, buku.getNomorTelepon());
            statement.setInt(5, buku.getDurasiSewa());
            statement.setInt(6, totalBiaya);
            statement.setInt(7, buku.getId());
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Update Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public void delete(int id) {
        try {
            String query = "DELETE FROM sewa_buku WHERE id=?";
            PreparedStatement statement = Connector.connect().prepareStatement(query);
            statement.setInt(1, id);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Delete Failed: " + e.getLocalizedMessage());
        }
    }

    @Override
    public List<ModelBuku> getAll() {
        List<ModelBuku> listBuku = new ArrayList<>();
        try {
            Statement statement = Connector.connect().createStatement();
            String query = "SELECT * FROM sewa_buku";
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                ModelBuku buku = new ModelBuku(
                    resultSet.getInt("id"),
                    resultSet.getString("nama_penyewa"),
                    resultSet.getString("judul_buku"),
                    resultSet.getString("jenis_buku"),
                    resultSet.getString("nomor_telepon"),
                    resultSet.getInt("durasi_sewa")
                );
                buku.setTotalBiaya(resultSet.getInt("total_biaya")); // Mengambil total biaya dari database
                listBuku.add(buku);
            }
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error: " + e.getLocalizedMessage());
        }
        return listBuku;
    }

    private int hitungTotalBiaya(int durasiSewa) {
        int biayaDasar = 10000;
        if (durasiSewa <= 2) {
            return durasiSewa * biayaDasar;
        } else {
            return (2 * biayaDasar) + ((durasiSewa - 2) * 5000);
        }
    }
}
