package Model.Buku;

public class ModelBuku {
    private int id;
    private String namaPenyewa;
    private String judulBuku;
    private String jenisBuku;
    private String nomorTelepon;
    private int durasiSewa;
    private int totalBiaya;

    // Constructor
    public ModelBuku(int id, String namaPenyewa, String judulBuku, String jenisBuku, String nomorTelepon, int durasiSewa) {
        this.id = id;
        this.namaPenyewa = namaPenyewa;
        this.judulBuku = judulBuku;
        this.jenisBuku = jenisBuku;
        this.nomorTelepon = nomorTelepon;
        this.durasiSewa = durasiSewa;
        this.totalBiaya = hitungTotalBiaya(durasiSewa);
    }

    // Method untuk menghitung total biaya
    private int hitungTotalBiaya(int durasiSewa) {
        int biayaDasar = 10000;
        if (durasiSewa <= 2) {
            return durasiSewa * biayaDasar;
        } else {
            return (2 * biayaDasar) + ((durasiSewa - 2) * 5000);
        }
    }

    // Getter and Setter methods
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNamaPenyewa() {
        return namaPenyewa;
    }

    public void setNamaPenyewa(String namaPenyewa) {
        this.namaPenyewa = namaPenyewa;
    }

    public String getJudulBuku() {
        return judulBuku;
    }

    public void setJudulBuku(String judulBuku) {
        this.judulBuku = judulBuku;
    }

    public String getJenisBuku() {
        return jenisBuku;
    }

    public void setJenisBuku(String jenisBuku) {
        this.jenisBuku = jenisBuku;
    }

    public String getNomorTelepon() {
        return nomorTelepon;
    }

    public void setNomorTelepon(String nomorTelepon) {
        this.nomorTelepon = nomorTelepon;
    }

    public int getDurasiSewa() {
        return durasiSewa;
    }

    public void setDurasiSewa(int durasiSewa) {
        this.durasiSewa = durasiSewa;
        this.totalBiaya = hitungTotalBiaya(durasiSewa); // Update total biaya saat durasi sewa diubah
    }

    public int getTotalBiaya() {
        return totalBiaya;
    }

    public void setTotalBiaya(int totalBiaya) {
        this.totalBiaya = totalBiaya;
    }
}
