package Model.Buku;

import java.util.List;

public interface InterfaceDAOBuku {
    // Method untuk memasukkan suatu data penyewaan buku
    public void insert(ModelBuku buku);
    
    // Method untuk mengupdate (mengedit) suatu data penyewaan buku
    public void update(ModelBuku buku);
    
    // Method untuk menghapus suatu data penyewaan buku berdasarkan ID
    public void delete(int id);
    
    // Method untuk mengambil semua data penyewaan buku
    public List<ModelBuku> getAll();
}
