package View.Buku;

import Controller.ControllerBuku;
import Model.Buku.ModelTable;
import Model.Buku.ModelBuku;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ViewData extends JFrame {
    private JTable tableBooks;

    public JTable getTableBooks() {
        return tableBooks;
    }

    ControllerBuku controller;
    JTable table;
    JScrollPane scrollPane;
    JButton addButton, editButton, deleteButton, backButton;

    public ViewData() {
        setTitle("Data Buku");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        controller = new ControllerBuku(this);
        JLabel header = new JLabel("Data Buku");
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.BLUE);
        header.setBounds(20, 20, 300, 30);
        add(header);

        addButton = new JButton("Tambah Data");
        addButton.setFont(new Font("Arial", Font.BOLD, 14));
        addButton.setBackground(Color.GREEN);
        addButton.setForeground(Color.WHITE);
        addButton.setBounds(20, 60, 150, 30);
        add(addButton);

        editButton = new JButton("Edit Data");
        editButton.setFont(new Font("Arial", Font.BOLD, 14));
        editButton.setBackground(Color.ORANGE);
        editButton.setForeground(Color.WHITE);
        editButton.setBounds(180, 60, 150, 30);
        add(editButton);

        deleteButton = new JButton("Hapus Data");
        deleteButton.setFont(new Font("Arial", Font.BOLD, 14));
        deleteButton.setBackground(Color.RED);
        deleteButton.setForeground(Color.WHITE);
        deleteButton.setBounds(340, 60, 150, 30);
        add(deleteButton);

        backButton = new JButton("Kembali");
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.setBackground(Color.GRAY);
        backButton.setForeground(Color.WHITE);
        backButton.setBounds(500, 60, 150, 30);
        add(backButton);

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new InputData();
            }
        });

        editButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    int id = (int) table.getValueAt(row, 0);
                    controller.editBook(id);
                } else {
                    JOptionPane.showMessageDialog(null, "Pilih data yang ingin diedit");
                }
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int row = table.getSelectedRow();
                if (row != -1) {
                    int id = (int) table.getValueAt(row, 0);
                    controller.deleteBook(id);
                } else {
                    JOptionPane.showMessageDialog(null, "Pilih data yang ingin dihapus");
                }
            }
        });

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new InputData();
            }
        });

       // Inisialisasi tabel
List<ModelBuku> listBuku = controller.getAll();
ModelTable modelTable = new ModelTable(listBuku);
table = new JTable(modelTable);
scrollPane = new JScrollPane(table);
scrollPane.setBounds(20, 100, 740, 240);
add(scrollPane);

// Tambahkan inisialisasi table di atas
table = new JTable(modelTable);

        setVisible(true);
    }

    public void refreshTable() {
        List<ModelBuku> listBuku = controller.getAll();
        ModelTable modelTable = new ModelTable(listBuku);
        table.setModel(modelTable);
    }
}
