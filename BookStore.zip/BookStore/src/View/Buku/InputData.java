package View.Buku;

import Controller.ControllerBuku;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InputData extends JFrame {
    // Membuat sebuah instance bernama controller dari class "ControllerBuku".
    ControllerBuku controller;
    
    JLabel header = new JLabel("Input Data Penyewaan Buku");
    JLabel labelInputNama = new JLabel("Nama Penyewa");
    JLabel labelInputJudul = new JLabel("Judul Buku");
    JLabel labelInputJenis = new JLabel("Jenis Buku");
    JLabel labelInputTelepon = new JLabel("Nomor Telepon");
    JLabel labelInputDurasi = new JLabel("Durasi Sewa (hari)");
    
    JTextField inputNama = new JTextField();
    JTextField inputJudul = new JTextField();
    JTextField inputJenis = new JTextField();
    JTextField inputTelepon = new JTextField();
    JTextField inputDurasi = new JTextField();
    
    JButton tombolTambah = new JButton("Tambah Data Penyewaan");
    JButton tombolKembali = new JButton("Kembali");

    public InputData() {
        setTitle("Input Data Penyewaan Buku");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setSize(480, 450); // Menyesuaikan lebar frame
        
        // Mengatur font dan warna untuk tampilan yang lebih menarik
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.BLUE);
        
        labelInputNama.setFont(new Font("Arial", Font.PLAIN, 16));
        labelInputJudul.setFont(new Font("Arial", Font.PLAIN, 16));
        labelInputJenis.setFont(new Font("Arial", Font.PLAIN, 16));
        labelInputTelepon.setFont(new Font("Arial", Font.PLAIN, 16));
        labelInputDurasi.setFont(new Font("Arial", Font.PLAIN, 16));
        
        inputNama.setFont(new Font("Arial", Font.PLAIN, 16));
        inputJudul.setFont(new Font("Arial", Font.PLAIN, 16));
        inputJenis.setFont(new Font("Arial", Font.PLAIN, 16));
        inputTelepon.setFont(new Font("Arial", Font.PLAIN, 16));
        inputDurasi.setFont(new Font("Arial", Font.PLAIN, 16));
        
        tombolTambah.setFont(new Font("Arial", Font.BOLD, 16));
        tombolTambah.setBackground(Color.GREEN);
        tombolTambah.setForeground(Color.WHITE);
        
        tombolKembali.setFont(new Font("Arial", Font.BOLD, 16));
        tombolKembali.setBackground(Color.RED);
        tombolKembali.setForeground(Color.WHITE);

        add(header);
        add(labelInputNama);
        add(labelInputJudul);
        add(labelInputJenis);
        add(labelInputTelepon);
        add(labelInputDurasi);
        add(inputNama);
        add(inputJudul);
        add(inputJenis);
        add(inputTelepon);
        add(inputDurasi);
        add(tombolTambah);
        add(tombolKembali);

        header.setBounds(80, 8, 320, 30);
        labelInputNama.setBounds(20, 50, 200, 24);
        inputNama.setBounds(20, 75, 440, 36);
        labelInputJudul.setBounds(20, 115, 200, 24);
        inputJudul.setBounds(20, 140, 440, 36);
        labelInputJenis.setBounds(20, 180, 200, 24);
        inputJenis.setBounds(20, 205, 440, 36);
        labelInputTelepon.setBounds(20, 245, 200, 24);
        inputTelepon.setBounds(20, 270, 440, 36);
        labelInputDurasi.setBounds(20, 310, 200, 24);
        inputDurasi.setBounds(20, 335, 440, 36);
        tombolKembali.setBounds(20, 380, 215, 40);
        tombolTambah.setBounds(240, 380, 215, 40);

        controller = new ControllerBuku(this); // Kita panggil konstruktor ControllerBuku dengan parameter InputData

        tombolKembali.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new ViewData();
            }
        });

        tombolTambah.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                controller.insertBook();
            }
        });
    }
    
    public String getInputNama() {
        return inputNama.getText();
    }
    
    public String getInputJudul() {
        return inputJudul.getText();
    }
    
    public String getInputJenis() {
        return inputJenis.getText();
    }
    
    public String getInputNomorTelepon() {
        return inputTelepon.getText();
    }
    
    public int getInputDurasiSewa() {
        try {
            return Integer.parseInt(inputDurasi.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Durasi sewa harus berupa angka.");
            return 0;
        }
    }
}
