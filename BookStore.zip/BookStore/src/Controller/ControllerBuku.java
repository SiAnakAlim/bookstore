package Controller;

import Model.Buku.*;
import View.Buku.*;
import java.util.List;
import javax.swing.JOptionPane;

public class ControllerBuku {

    ViewData halamanTable;
    InputData halamanInput;
    EditData halamanEdit;

    InterfaceDAOBuku daoBuku;

    // Variabel untuk menyimpan data buku dari database
    List<ModelBuku> daftarBuku;
    
    // Constructor untuk halaman Table Buku
    public ControllerBuku(ViewData halamanTable) {
        this.halamanTable = halamanTable;
        this.daoBuku = new DAOBuku();
    }

    // Constructor untuk halaman Input Buku
    public ControllerBuku(InputData halamanInput) {
        this.halamanInput = halamanInput;
        this.daoBuku = new DAOBuku();
    }

    // Constructor untuk halaman Edit Buku
    public ControllerBuku(EditData halamanEdit) {
        this.halamanEdit = halamanEdit;
        this.daoBuku = new DAOBuku();
    }

    // Method untuk menampilkan semua buku pada tabel
    public void showAllBooks() {
        daftarBuku = daoBuku.getAll();
        ModelTable table = new ModelTable(daftarBuku);
        halamanTable.getTableBooks().setModel(table); // Menggunakan getTableBooks() untuk mendapatkan tabel
    }

    // Method untuk mendapatkan semua data buku
    public List<ModelBuku> getAll() {
        return daoBuku.getAll();
    }

public void insertBook() {
    try {
        String namaPenyewa = halamanInput.getInputNama();
        String judulBuku = halamanInput.getInputJudul();
        String jenisBuku = halamanInput.getInputJenis();
        String nomorTelepon = halamanInput.getInputNomorTelepon();
        int durasiSewa = halamanInput.getInputDurasiSewa();

        if (namaPenyewa.isEmpty() || judulBuku.isEmpty() || jenisBuku.isEmpty() || nomorTelepon.isEmpty() || durasiSewa <= 0) {
            throw new Exception("Harap lengkapi semua field dengan benar.");
        }

        // Buat objek ModelBuku dengan menggunakan konstruktor yang ada
        ModelBuku bukuBaru = new ModelBuku(0, namaPenyewa, judulBuku, jenisBuku, nomorTelepon, durasiSewa);

        daoBuku.insert(bukuBaru);
        JOptionPane.showMessageDialog(null, "Data buku berhasil ditambahkan.");
        halamanInput.dispose();
        
        // Periksa jika halamanTable telah diinisialisasi sebelum memanggil showAllBooks
        if (halamanTable != null) {
            showAllBooks(); // Refresh tabel setelah penambahan
        }
        
        // Kembali ke tampilan menu awal
        kembaliKeMenuAwal();
        
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
    }
}

// Method untuk kembali ke tampilan menu awal
private void kembaliKeMenuAwal() {
    // Buat instance ViewData dan tampilkan
    ViewData menuAwal = new ViewData();
    menuAwal.setVisible(true);
}



// Method untuk mengedit data buku
public void editBook(int id) {
    try {
        // Membuat objek ModelBuku untuk menyimpan informasi buku yang akan diedit
        ModelBuku bukuYangMauDiedit = new ModelBuku(id, halamanEdit.getInputNama(), halamanEdit.getInputJudul(), halamanEdit.getInputJenis(), halamanEdit.getInputNomorTelepon(), halamanEdit.getInputDurasiSewa());

        // Memeriksa apakah input dari nama penyewa, judul buku, jenis buku, nomor telepon, atau durasi sewa kosong atau tidak
        if (bukuYangMauDiedit.getNamaPenyewa().isEmpty() || bukuYangMauDiedit.getJudulBuku().isEmpty() || bukuYangMauDiedit.getJenisBuku().isEmpty() || bukuYangMauDiedit.getNomorTelepon().isEmpty() || bukuYangMauDiedit.getDurasiSewa() <= 0) {
            throw new Exception("Harap lengkapi semua field dengan benar.");
        }

        // Memperbarui data buku di database
        daoBuku.update(bukuYangMauDiedit);

        // Menampilkan pesan berhasil
        JOptionPane.showMessageDialog(null, "Data buku berhasil diubah.");

        // Menutup halaman edit
        halamanEdit.dispose();

        // Refresh tabel setelah pengeditan
        showAllBooks();
    } catch (Exception e) {
        // Menampilkan pesan error jika terjadi kesalahan
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
    }
}




   public void deleteBook(int baris) {
    try {
        // Mengambil id, nama buku berdasarkan baris yang dipilih
        int id = (int) halamanTable.getTableBooks().getValueAt(baris, 0);
        String judulBuku = halamanTable.getTableBooks().getValueAt(baris, 1).toString();

        // Membuat pop-up untuk mengonfirmasi penghapusan data
        int input = JOptionPane.showConfirmDialog(
                null,
                "Hapus " + judulBuku + "?",
                "Hapus Buku",
                JOptionPane.YES_NO_OPTION
        );

        // Jika pengguna memilih opsi "yes", maka hapus data.
        if (input == 0) {
            // Memanggil method delete() untuk menghapus data dari database berdasarkan id yang dipilih.
            daoBuku.delete(id);

            // Menampilkan pop-up jika berhasil menghapus.
            JOptionPane.showMessageDialog(null, "Data buku berhasil dihapus.");

            // Memanggil method showAllBooks() untuk merefresh tabel.
            showAllBooks();
        }
    } catch (Exception e) {
        // Menampilkan pop-up jika terjadi kesalahan.
        JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
    }
}

}
